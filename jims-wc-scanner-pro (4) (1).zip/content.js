// Content script — bridges injected.js (MAIN world) and popup/extension
// Saves seats DIRECTLY to chrome.storage.local

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const d = event.data;
  if (!d?.type) return;

  // Seat data from injected.js
  if (d.type === "FIFA_TICKET_SCOUT" && d.body?.features?.length > 0) {
    const perfId = extractParam(d.url || "", "performanceId");
    if (perfId) saveSeats(perfId, d.body.features);
  }

  // Scan progress
  if (d.type === "FIFA_TICKET_SCOUT_SCAN_PROGRESS") {
    chrome.runtime.sendMessage({
      type: "SCAN_PROGRESS",
      performanceId: d.performanceId,
      completed: d.completed,
      done: d.completed,
      total: d.total,
      status: d.status,
      eta: d.eta,
    }).catch(() => {});
    if (d.status === "done" || d.status === "captcha") {
      chrome.runtime.sendMessage({ type: "SCAN_DONE", performanceId: d.performanceId }).catch(() => {});
      // Sync to Supabase directly from content.js (background might be asleep)
      syncToSupabase(d.performanceId);
    }
  }
});

const SUPABASE_URL = "https://bpqysjydesqukjvzwvhy.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJwcXlzanlkZXNxdWtqdnp3dmh5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYyMDM2NTMsImV4cCI6MjA5MTc3OTY1M30.xAQGjpxmVe1CbgaWIH5yoMZb-Lm6BwGCuH8x590_bvA";
const FIFA_FEE = 1.15;

const PERF_TO_GAME = {"10229225516056":"M1|Mexico|South Africa","10229226700886":"M2|South Korea|Czechia","10229226700887":"M3|Canada|Bosnia & Herz.","10229226700888":"M4|USA|Paraguay","10229226700889":"M5|Haiti|Scotland","10229226700890":"M6|Australia|Türkiye","10229226700891":"M7|Brazil|Morocco","10229226700892":"M8|Qatar|Switzerland","10229226700893":"M9|Ivory Coast|Ecuador","10229226700895":"M10|Germany|Curaçao","10229226700896":"M11|Netherlands|Japan","10229226700906":"M12|Sweden|Tunisia","10229226700899":"M13|Saudi Arabia|Uruguay","10229226700902":"M14|Spain|Cape Verde","10229226700901":"M15|Iran|New Zealand","10229226700903":"M16|Belgium|Egypt","10229226700904":"M17|France|Senegal","10229226700905":"M18|Iraq|Norway","10229226700907":"M19|Argentina|Algeria","10229226700908":"M20|Austria|Jordan","10229226700909":"M21|Ghana|Panama","10229226700910":"M22|England|Croatia","10229226700911":"M23|Portugal|DR Congo","10229226700912":"M24|Uzbekistan|Colombia","10229226700913":"M25|Czechia|South Africa","10229226700914":"M26|Switzerland|Bosnia & Herz.","10229226700915":"M27|Canada|Qatar","10229226700916":"M28|Mexico|South Korea","10229226700917":"M29|Brazil|Haiti","10229226700918":"M30|Scotland|Morocco","10229226700919":"M31|Türkiye|Paraguay","10229226700920":"M32|USA|Australia","10229226700921":"M33|Germany|Ivory Coast","10229226700922":"M34|Ecuador|Curaçao","10229226700923":"M35|Netherlands|Sweden","10229226700924":"M36|Tunisia|Japan","10229226700925":"M37|Uruguay|Cape Verde","10229226700926":"M38|Spain|Saudi Arabia","10229226700927":"M39|Belgium|Iran","10229226700928":"M40|New Zealand|Egypt","10229226700929":"M41|Norway|Senegal","10229226700930":"M42|France|Iraq","10229226700931":"M43|Argentina|Austria","10229226700932":"M44|Jordan|Algeria","10229226700933":"M45|England|Ghana","10229226700934":"M46|Panama|Croatia","10229226700935":"M47|Portugal|Uzbekistan","10229226700936":"M48|Colombia|DR Congo","10229226700937":"M49|Scotland|Brazil","10229226700938":"M50|Morocco|Haiti","10229226700941":"M51|Switzerland|Canada","10229226700942":"M52|Bosnia & Herz.|Qatar","10229226700940":"M53|Czechia|Mexico","10229226700939":"M54|South Africa|South Korea","10229226700943":"M55|Curaçao|Ivory Coast","10229226700944":"M56|Ecuador|Germany","10229226700945":"M57|Japan|Sweden","10229226700946":"M58|Tunisia|Netherlands","10229226700947":"M59|Türkiye|USA","10229226700948":"M60|Paraguay|Australia","10229226700949":"M61|Norway|France","10229226700950":"M62|Senegal|Iraq","10229226700951":"M63|Egypt|Iran","10229226700952":"M64|New Zealand|Belgium","10229226700953":"M65|Cape Verde|Saudi Arabia","10229226700954":"M66|Uruguay|Spain","10229226700955":"M67|Panama|England","10229226700956":"M68|Croatia|Ghana","10229226700959":"M69|Algeria|Austria","10229226700960":"M70|Jordan|Argentina","10229226700957":"M71|Colombia|Portugal","10229226700958":"M72|DR Congo|Uzbekistan","10229226725328":"M73|TBD|TBD","10229226725329":"M74|TBD|TBD","10229226725330":"M75|TBD|TBD","10229226725331":"M76|TBD|TBD","10229226725332":"M77|TBD|TBD","10229226725333":"M78|TBD|TBD","10229226725334":"M79|TBD|TBD","10229226725335":"M80|TBD|TBD","10229226725336":"M81|TBD|TBD","10229226725337":"M82|TBD|TBD","10229226725338":"M83|TBD|TBD","10229226725339":"M84|TBD|TBD","10229226725340":"M85|TBD|TBD","10229226725341":"M86|TBD|TBD","10229226725342":"M87|TBD|TBD","10229226725343":"M88|TBD|TBD","10229226725345":"M89|TBD|TBD","10229226725346":"M90|TBD|TBD","10229226725347":"M91|TBD|TBD","10229226725348":"M92|TBD|TBD","10229226725349":"M93|TBD|TBD","10229226725350":"M94|TBD|TBD","10229226725351":"M95|TBD|TBD","10229226725352":"M96|TBD|TBD","10229226725353":"M97|TBD|TBD","10229226725354":"M98|TBD|TBD","10229226725355":"M99|TBD|TBD","10229226725356":"M100|TBD|TBD","10229226725357":"M101|TBD|TBD","10229226725358":"M102|TBD|TBD","10229226725361":"M103|TBD|TBD","10229226725360":"M104|TBD|TBD"};

function syncToSupabase(perfId) {
  chrome.storage.local.get(["seats"], (data) => {
    const seats = data.seats?.[perfId];
    if (!seats || Object.keys(seats).length === 0) return;
    const seatList = Object.values(seats).map(s => ({
      seatId: s.seatId, block: s.block, row: s.row, seat: s.seat, category: s.category,
      price: s.price, usd: Math.round((s.price / 1000) * FIFA_FEE),
      resaleMovementId: s.resaleMovementId || "", exclusive: !!s.exclusive,
    }));
    const gameInfo = (PERF_TO_GAME[perfId] || "").split("|");
    const payload = {
      performance_id: perfId,
      license_hash: "user",
      match_code: gameInfo[0] || "",
      home: gameInfo[1] || "",
      away: gameInfo[2] || "",
      seat_count: seatList.length,
      seats: seatList,
    };
    fetch(`${SUPABASE_URL}/rest/v1/scan_data`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "apikey": SUPABASE_KEY, "Authorization": "Bearer " + SUPABASE_KEY, "Prefer": "return=minimal" },
      body: JSON.stringify(payload),
    }).catch(() => {});
  });
}

// Listen for scan commands from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "START_SCAN") {
    window.postMessage({
      type: "FIFA_TICKET_SCOUT_SCAN",
      productId: message.productId,
      performanceId: message.performanceId,
      scanSpeed: message.scanSpeed || "cautious",
    }, "*");
  }
});

function extractParam(url, param) {
  try { return new URL(url).searchParams.get(param); }
  catch {
    const m = url.match(new RegExp("[?&]" + param + "=([^&]+)"));
    return m ? m[1] : null;
  }
}

function saveSeats(perfId, features) {
  chrome.storage.local.get("seats", (data) => {
    const allSeats = data.seats || {};
    if (!allSeats[perfId]) allSeats[perfId] = {};
    for (const f of features) {
      const p = f.properties;
      if (!p) continue;
      const seatId = String(f.id || p.id || "");
      if (!seatId) continue;
      allSeats[perfId][seatId] = {
        seatId: seatId,
        block: p.block?.name?.en || "",
        row: p.row || "",
        seat: p.number || "",
        category: p.seatCategory || "",
        price: p.amount,
        resaleMovementId: String(p.resaleMovementId || ""),
        exclusive: !!p.exclusive,
      };
    }
    chrome.storage.local.set({ seats: allSeats }, () => {
      chrome.runtime.sendMessage({ type: "DATA_UPDATED" }).catch(() => {});
    });
  });
}

// ── Find Seat overlay ────────────────────────────────────────────────────────
if (window.location.href.includes("/selection/event/seat")) {
  setTimeout(() => {
    chrome.storage.local.get("findSeat", (data) => {
      if (!data.findSeat) return;
      const s = data.findSeat;
      chrome.storage.local.remove("findSeat");
      const banner = document.createElement("div");
      banner.style.cssText = "position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:99999;background:linear-gradient(135deg,#1a1a2e,#16213e);color:#fff;padding:12px 24px;border-radius:10px;font-family:system-ui,sans-serif;font-size:14px;box-shadow:0 4px 24px rgba(0,0,0,.5);border:1px solid rgba(34,197,94,.3);display:flex;align-items:center;gap:16px;";
      const cc = {1:"#22c55e",2:"#f59e0b",3:"#3b82f6",4:"#a855f7"};
      banner.innerHTML = '<div style="font-size:24px">🎯</div><div><div style="font-weight:700;font-size:16px;color:'+(cc[s.cat]||"#fff")+'">Block '+s.block+' · Row '+s.row+' · Seat '+s.seats+'</div><div style="font-size:12px;color:#8090a8;margin-top:2px">Cat '+s.cat+' · ~$'+s.usd+' — Click on Block '+s.block+' to zoom in</div></div><button style="background:none;border:none;color:#556070;font-size:18px;cursor:pointer;padding:4px 8px;margin-left:8px" id="jims-close">✕</button>';
      document.body.appendChild(banner);
      document.getElementById("jims-close").addEventListener("click", () => banner.remove());
      setTimeout(() => { if (banner.parentElement) banner.remove(); }, 60000);
    });
  }, 1000);
}
