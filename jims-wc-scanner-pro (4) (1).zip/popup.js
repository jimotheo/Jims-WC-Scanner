const FIFA_FEE=1.15,PRODUCT_ID="10229225515651",FIFA_ORIGIN="https://fwc26-resale-usd.tickets.fifa.com",PPG=12;

// ── All 104 games ────────────────────────────────────────────────────────────
const GAMES=[{c:"M1",p:"10229225516056",g:"A",h:"Mexico",a:"South Africa",d:"Thu 11 Jun",v:"Mexico City"},{c:"M2",p:"10229226700886",g:"A",h:"South Korea",a:"Czechia",d:"Thu 11 Jun",v:"Guadalajara"},{c:"M3",p:"10229226700887",g:"B",h:"Canada",a:"Bosnia & Herz.",d:"Fri 12 Jun",v:"Toronto"},{c:"M4",p:"10229226700888",g:"D",h:"USA",a:"Paraguay",d:"Fri 12 Jun",v:"Los Angeles"},{c:"M5",p:"10229226700889",g:"C",h:"Haiti",a:"Scotland",d:"Sat 13 Jun",v:"Boston"},{c:"M6",p:"10229226700890",g:"D",h:"Australia",a:"Türkiye",d:"Sat 13 Jun",v:"Vancouver"},{c:"M7",p:"10229226700891",g:"C",h:"Brazil",a:"Morocco",d:"Sat 13 Jun",v:"New York/NJ"},{c:"M8",p:"10229226700892",g:"B",h:"Qatar",a:"Switzerland",d:"Sat 13 Jun",v:"San Francisco"},{c:"M9",p:"10229226700893",g:"E",h:"Ivory Coast",a:"Ecuador",d:"Sun 14 Jun",v:"Philadelphia"},{c:"M10",p:"10229226700895",g:"E",h:"Germany",a:"Curaçao",d:"Sun 14 Jun",v:"Houston"},{c:"M11",p:"10229226700896",g:"F",h:"Netherlands",a:"Japan",d:"Sun 14 Jun",v:"Dallas"},{c:"M12",p:"10229226700906",g:"F",h:"Sweden",a:"Tunisia",d:"Sun 14 Jun",v:"Monterrey"},{c:"M13",p:"10229226700899",g:"H",h:"Saudi Arabia",a:"Uruguay",d:"Mon 15 Jun",v:"Miami"},{c:"M14",p:"10229226700902",g:"H",h:"Spain",a:"Cape Verde",d:"Mon 15 Jun",v:"Atlanta"},{c:"M15",p:"10229226700901",g:"G",h:"Iran",a:"New Zealand",d:"Mon 15 Jun",v:"Los Angeles"},{c:"M16",p:"10229226700903",g:"G",h:"Belgium",a:"Egypt",d:"Mon 15 Jun",v:"Seattle"},{c:"M17",p:"10229226700904",g:"I",h:"France",a:"Senegal",d:"Tue 16 Jun",v:"New York/NJ"},{c:"M18",p:"10229226700905",g:"I",h:"Iraq",a:"Norway",d:"Tue 16 Jun",v:"Boston"},{c:"M19",p:"10229226700907",g:"J",h:"Argentina",a:"Algeria",d:"Tue 16 Jun",v:"Kansas City"},{c:"M20",p:"10229226700908",g:"J",h:"Austria",a:"Jordan",d:"Tue 16 Jun",v:"San Francisco"},{c:"M21",p:"10229226700909",g:"L",h:"Ghana",a:"Panama",d:"Wed 17 Jun",v:"Toronto"},{c:"M22",p:"10229226700910",g:"L",h:"England",a:"Croatia",d:"Wed 17 Jun",v:"Dallas"},{c:"M23",p:"10229226700911",g:"K",h:"Portugal",a:"DR Congo",d:"Wed 17 Jun",v:"Houston"},{c:"M24",p:"10229226700912",g:"K",h:"Uzbekistan",a:"Colombia",d:"Wed 17 Jun",v:"Mexico City"},{c:"M25",p:"10229226700913",g:"A",h:"Czechia",a:"South Africa",d:"Thu 18 Jun",v:"Atlanta"},{c:"M26",p:"10229226700914",g:"B",h:"Switzerland",a:"Bosnia & Herz.",d:"Thu 18 Jun",v:"Los Angeles"},{c:"M27",p:"10229226700915",g:"B",h:"Canada",a:"Qatar",d:"Thu 18 Jun",v:"Vancouver"},{c:"M28",p:"10229226700916",g:"A",h:"Mexico",a:"South Korea",d:"Thu 18 Jun",v:"Guadalajara"},{c:"M29",p:"10229226700917",g:"C",h:"Brazil",a:"Haiti",d:"Fri 19 Jun",v:"Philadelphia"},{c:"M30",p:"10229226700918",g:"C",h:"Scotland",a:"Morocco",d:"Fri 19 Jun",v:"Boston"},{c:"M31",p:"10229226700919",g:"D",h:"Türkiye",a:"Paraguay",d:"Fri 19 Jun",v:"San Francisco"},{c:"M32",p:"10229226700920",g:"D",h:"USA",a:"Australia",d:"Fri 19 Jun",v:"Seattle"},{c:"M33",p:"10229226700921",g:"E",h:"Germany",a:"Ivory Coast",d:"Sat 20 Jun",v:"Toronto"},{c:"M34",p:"10229226700922",g:"E",h:"Ecuador",a:"Curaçao",d:"Sat 20 Jun",v:"Kansas City"},{c:"M35",p:"10229226700923",g:"F",h:"Netherlands",a:"Sweden",d:"Sat 20 Jun",v:"Houston"},{c:"M36",p:"10229226700924",g:"F",h:"Tunisia",a:"Japan",d:"Sat 20 Jun",v:"Monterrey"},{c:"M37",p:"10229226700925",g:"H",h:"Uruguay",a:"Cape Verde",d:"Sun 21 Jun",v:"Miami"},{c:"M38",p:"10229226700926",g:"H",h:"Spain",a:"Saudi Arabia",d:"Sun 21 Jun",v:"Atlanta"},{c:"M39",p:"10229226700927",g:"G",h:"Belgium",a:"Iran",d:"Sun 21 Jun",v:"Los Angeles"},{c:"M40",p:"10229226700928",g:"G",h:"New Zealand",a:"Egypt",d:"Sun 21 Jun",v:"Vancouver"},{c:"M41",p:"10229226700929",g:"I",h:"Norway",a:"Senegal",d:"Mon 22 Jun",v:"New York/NJ"},{c:"M42",p:"10229226700930",g:"I",h:"France",a:"Iraq",d:"Mon 22 Jun",v:"Philadelphia"},{c:"M43",p:"10229226700931",g:"J",h:"Argentina",a:"Austria",d:"Mon 22 Jun",v:"Dallas"},{c:"M44",p:"10229226700932",g:"J",h:"Jordan",a:"Algeria",d:"Mon 22 Jun",v:"San Francisco"},{c:"M45",p:"10229226700933",g:"L",h:"England",a:"Ghana",d:"Tue 23 Jun",v:"Boston"},{c:"M46",p:"10229226700934",g:"L",h:"Panama",a:"Croatia",d:"Tue 23 Jun",v:"Toronto"},{c:"M47",p:"10229226700935",g:"K",h:"Portugal",a:"Uzbekistan",d:"Tue 23 Jun",v:"Houston"},{c:"M48",p:"10229226700936",g:"K",h:"Colombia",a:"DR Congo",d:"Tue 23 Jun",v:"Guadalajara"},{c:"M49",p:"10229226700937",g:"C",h:"Scotland",a:"Brazil",d:"Wed 24 Jun",v:"Miami"},{c:"M50",p:"10229226700938",g:"C",h:"Morocco",a:"Haiti",d:"Wed 24 Jun",v:"Atlanta"},{c:"M51",p:"10229226700941",g:"B",h:"Switzerland",a:"Canada",d:"Wed 24 Jun",v:"Vancouver"},{c:"M52",p:"10229226700942",g:"B",h:"Bosnia & Herz.",a:"Qatar",d:"Wed 24 Jun",v:"Seattle"},{c:"M53",p:"10229226700940",g:"A",h:"Czechia",a:"Mexico",d:"Wed 24 Jun",v:"Mexico City"},{c:"M54",p:"10229226700939",g:"A",h:"South Africa",a:"South Korea",d:"Wed 24 Jun",v:"Monterrey"},{c:"M55",p:"10229226700943",g:"E",h:"Curaçao",a:"Ivory Coast",d:"Thu 25 Jun",v:"Philadelphia"},{c:"M56",p:"10229226700944",g:"E",h:"Ecuador",a:"Germany",d:"Thu 25 Jun",v:"New York/NJ"},{c:"M57",p:"10229226700945",g:"F",h:"Japan",a:"Sweden",d:"Thu 25 Jun",v:"Dallas"},{c:"M58",p:"10229226700946",g:"F",h:"Tunisia",a:"Netherlands",d:"Thu 25 Jun",v:"Kansas City"},{c:"M59",p:"10229226700947",g:"D",h:"Türkiye",a:"USA",d:"Thu 25 Jun",v:"Los Angeles"},{c:"M60",p:"10229226700948",g:"D",h:"Paraguay",a:"Australia",d:"Thu 25 Jun",v:"San Francisco"},{c:"M61",p:"10229226700949",g:"I",h:"Norway",a:"France",d:"Fri 26 Jun",v:"Boston"},{c:"M62",p:"10229226700950",g:"I",h:"Senegal",a:"Iraq",d:"Fri 26 Jun",v:"Toronto"},{c:"M63",p:"10229226700951",g:"G",h:"Egypt",a:"Iran",d:"Fri 26 Jun",v:"Seattle"},{c:"M64",p:"10229226700952",g:"G",h:"New Zealand",a:"Belgium",d:"Fri 26 Jun",v:"Vancouver"},{c:"M65",p:"10229226700953",g:"H",h:"Cape Verde",a:"Saudi Arabia",d:"Fri 26 Jun",v:"Houston"},{c:"M66",p:"10229226700954",g:"H",h:"Uruguay",a:"Spain",d:"Fri 26 Jun",v:"Guadalajara"},{c:"M67",p:"10229226700955",g:"L",h:"Panama",a:"England",d:"Sat 27 Jun",v:"New York/NJ"},{c:"M68",p:"10229226700956",g:"L",h:"Croatia",a:"Ghana",d:"Sat 27 Jun",v:"Philadelphia"},{c:"M69",p:"10229226700959",g:"J",h:"Algeria",a:"Austria",d:"Sat 27 Jun",v:"Kansas City"},{c:"M70",p:"10229226700960",g:"J",h:"Jordan",a:"Argentina",d:"Sat 27 Jun",v:"Dallas"},{c:"M71",p:"10229226700957",g:"K",h:"Colombia",a:"Portugal",d:"Sat 27 Jun",v:"Miami"},{c:"M72",p:"10229226700958",g:"K",h:"DR Congo",a:"Uzbekistan",d:"Sat 27 Jun",v:"Atlanta"},{c:"M73",p:"10229226725328",g:"R32",h:"TBD",a:"TBD",d:"Sun 28 Jun",v:"Los Angeles"},{c:"M74",p:"10229226725329",g:"R32",h:"TBD",a:"TBD",d:"Mon 29 Jun",v:"Boston"},{c:"M75",p:"10229226725330",g:"R32",h:"TBD",a:"TBD",d:"Mon 29 Jun",v:"Monterrey"},{c:"M76",p:"10229226725331",g:"R32",h:"TBD",a:"TBD",d:"Mon 29 Jun",v:"Houston"},{c:"M77",p:"10229226725332",g:"R32",h:"TBD",a:"TBD",d:"Tue 30 Jun",v:"New York/NJ"},{c:"M78",p:"10229226725333",g:"R32",h:"TBD",a:"TBD",d:"Tue 30 Jun",v:"Dallas"},{c:"M79",p:"10229226725334",g:"R32",h:"TBD",a:"TBD",d:"Tue 30 Jun",v:"Mexico City"},{c:"M80",p:"10229226725335",g:"R32",h:"TBD",a:"TBD",d:"Wed 1 Jul",v:"Atlanta"},{c:"M81",p:"10229226725336",g:"R32",h:"TBD",a:"TBD",d:"Wed 1 Jul",v:"San Francisco"},{c:"M82",p:"10229226725337",g:"R32",h:"TBD",a:"TBD",d:"Wed 1 Jul",v:"Seattle"},{c:"M83",p:"10229226725338",g:"R32",h:"TBD",a:"TBD",d:"Thu 2 Jul",v:"Toronto"},{c:"M84",p:"10229226725339",g:"R32",h:"TBD",a:"TBD",d:"Thu 2 Jul",v:"Los Angeles"},{c:"M85",p:"10229226725340",g:"R32",h:"TBD",a:"TBD",d:"Thu 2 Jul",v:"Vancouver"},{c:"M86",p:"10229226725341",g:"R32",h:"TBD",a:"TBD",d:"Fri 3 Jul",v:"Miami"},{c:"M87",p:"10229226725342",g:"R32",h:"TBD",a:"TBD",d:"Fri 3 Jul",v:"Kansas City"},{c:"M88",p:"10229226725343",g:"R32",h:"TBD",a:"TBD",d:"Fri 3 Jul",v:"Dallas"},{c:"M89",p:"10229226725345",g:"R16",h:"TBD",a:"TBD",d:"Sat 4 Jul",v:"Philadelphia"},{c:"M90",p:"10229226725346",g:"R16",h:"TBD",a:"TBD",d:"Sat 4 Jul",v:"Houston"},{c:"M91",p:"10229226725347",g:"R16",h:"TBD",a:"TBD",d:"Sun 5 Jul",v:"New York/NJ"},{c:"M92",p:"10229226725348",g:"R16",h:"TBD",a:"TBD",d:"Sun 5 Jul",v:"Mexico City"},{c:"M93",p:"10229226725349",g:"R16",h:"TBD",a:"TBD",d:"Mon 6 Jul",v:"Dallas"},{c:"M94",p:"10229226725350",g:"R16",h:"TBD",a:"TBD",d:"Mon 6 Jul",v:"Seattle"},{c:"M95",p:"10229226725351",g:"R16",h:"TBD",a:"TBD",d:"Tue 7 Jul",v:"Atlanta"},{c:"M96",p:"10229226725352",g:"R16",h:"TBD",a:"TBD",d:"Tue 7 Jul",v:"Vancouver"},{c:"M97",p:"10229226725353",g:"QF",h:"TBD",a:"TBD",d:"Thu 9 Jul",v:"Boston"},{c:"M98",p:"10229226725354",g:"QF",h:"TBD",a:"TBD",d:"Fri 10 Jul",v:"Los Angeles"},{c:"M99",p:"10229226725355",g:"QF",h:"TBD",a:"TBD",d:"Sat 11 Jul",v:"Miami"},{c:"M100",p:"10229226725356",g:"QF",h:"TBD",a:"TBD",d:"Sat 11 Jul",v:"Kansas City"},{c:"M101",p:"10229226725357",g:"SF",h:"TBD",a:"TBD",d:"Tue 14 Jul",v:"Dallas"},{c:"M102",p:"10229226725358",g:"SF",h:"TBD",a:"TBD",d:"Wed 15 Jul",v:"Atlanta"},{c:"M103",p:"10229226725361",g:"3P",h:"TBD",a:"TBD",d:"Sat 18 Jul",v:"Miami"},{c:"M104",p:"10229226725360",g:"F",h:"TBD",a:"TBD",d:"Sun 19 Jul",v:"New York/NJ"}];

const FV={1:{1:450,2:380,3:140,4:60},2:{1:450,2:380,3:140,4:60},3:{1:450,2:380,3:140,4:60},4:{1:700,2:500,3:265,4:60},5:{1:450,2:380,3:140,4:105},6:{1:500,2:400,3:180,4:60},7:{1:790,2:575,3:315,4:105},8:{1:500,2:400,3:180,4:60},9:{1:600,2:430,3:220,4:75},10:{1:500,2:400,3:180,4:60},11:{1:500,2:400,3:180,4:60},12:{1:450,2:380,3:140,4:60},13:{1:500,2:400,3:180,4:60},14:{1:500,2:400,3:180,4:60},15:{1:500,2:400,3:180,4:60},16:{1:500,2:400,3:180,4:60},17:{1:675,2:520,3:255,4:60},18:{1:500,2:400,3:180,4:60},19:{1:500,2:400,3:180,4:60},20:{1:500,2:400,3:180,4:60},21:{1:500,2:400,3:180,4:60},22:{1:500,2:400,3:180,4:60},23:{1:500,2:400,3:180,4:60},24:{1:500,2:400,3:180,4:60},25:{1:450,2:380,3:140,4:60},26:{1:500,2:400,3:180,4:60},27:{1:500,2:400,3:180,4:60},28:{1:450,2:380,3:140,4:60},29:{1:775,2:570,3:310,4:90},30:{1:450,2:380,3:140,4:60},31:{1:500,2:400,3:180,4:60},32:{1:700,2:500,3:265,4:60},33:{1:500,2:400,3:180,4:60},34:{1:500,2:400,3:180,4:60},35:{1:500,2:400,3:180,4:60},36:{1:500,2:400,3:180,4:60},37:{1:500,2:400,3:180,4:60},38:{1:500,2:400,3:180,4:60},39:{1:500,2:400,3:180,4:60},40:{1:450,2:380,3:140,4:70},41:{1:775,2:570,3:315,4:60},42:{1:600,2:430,3:220,4:60},43:{1:620,2:465,3:220,4:60},44:{1:450,2:380,3:140,4:60},45:{1:500,2:400,3:180,4:60},46:{1:700,2:500,3:265,4:60},47:{1:660,2:490,3:260,4:60},48:{1:555,2:455,3:215,4:60},49:{1:700,2:500,3:265,4:80},50:{1:500,2:400,3:180,4:60},51:{1:770,2:570,3:310,4:60},52:{1:500,2:400,3:180,4:60},53:{1:785,2:585,3:320,4:90},54:{1:450,2:380,3:140,4:60},55:{1:450,2:380,3:140,4:60},56:{1:790,2:575,3:315,4:60},57:{1:500,2:400,3:180,4:60},58:{1:500,2:400,3:180,4:60},59:{1:990,2:840,3:390,4:140},60:{1:450,2:380,3:140,4:60},61:{1:775,2:570,3:310,4:60},62:{1:450,2:380,3:140,4:60},63:{1:450,2:380,3:140,4:60},64:{1:780,2:575,3:315,4:60},65:{1:500,2:400,3:180,4:60},66:{1:500,2:400,3:180,4:60},67:{1:675,2:520,3:255,4:105},68:{1:500,2:400,3:180,4:75},69:{1:890,2:665,3:375,4:75},70:{1:450,2:380,3:140,4:70},71:{1:450,2:380,3:140,4:70},72:{1:765,2:565,3:310,4:75},73:{1:790,2:605,3:305,4:185},74:{1:620,2:515,3:265,4:125},75:{1:460,2:350,3:190,4:105},76:{1:530,2:430,3:220,4:125},77:{1:750,2:610,3:280,4:185},78:{1:505,2:405,3:205,4:135},79:{1:685,2:550,3:280,4:125},80:{1:530,2:430,3:190,4:125},81:{1:765,2:605,3:275,4:185},82:{1:515,2:430,3:200,4:125},83:{1:695,2:545,3:285,4:135},84:{1:700,2:555,3:250,4:185},85:{1:645,2:570,3:260,4:125},86:{1:770,2:635,3:315,4:135},87:{1:520,2:425,3:200,4:125},88:{1:540,2:440,3:225,4:135},89:{1:905,2:685,3:365,4:185},90:{1:620,2:505,3:220,4:170},91:{1:1055,2:865,3:415,4:260},92:{1:960,2:695,3:400,4:170},93:{1:640,2:515,3:240,4:185},94:{1:695,2:565,3:270,4:170},95:{1:795,2:640,3:305,4:180},96:{1:845,2:705,3:370,4:170},97:{1:1400,2:1005,3:750,4:275},98:{1:1910,2:1345,3:900,4:410},99:{1:1590,2:1135,3:850,4:295},100:{1:1360,2:1035,3:605,4:275},101:{1:3710,2:2705,3:1095,4:455},102:{1:3220,2:2725,3:995,4:420},103:{1:1125,2:865,3:455,4:165},104:{1:10990,2:7380,3:5785,4:2030}};

let allSeats={},selGame=null,catFilter="all",page=0,scanning=false,autoOn=false,autoAbort=false,globalStop=false;
let currentScanPerfId=null,scanDoneResolve=null;
const alertedGames=new Set();
let scanCooldown = 0; // seconds remaining before next scan allowed
let cooldownTimer = null;

// ── Init ─────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded",()=>{
  showApp();
});

function showApp(){
  document.getElementById("app").classList.remove("hidden");
  chrome.storage.local.get("seats",d=>{allSeats=d.seats||{};renderTable();refreshAll();});
  bindEvents();
  // Check for FIFA tab
  chrome.tabs.query({url:"*://*.tickets.fifa.com/*"},tabs=>{
    if(!tabs||tabs.length===0){
      document.getElementById("last-scan").textContent="⚠ Open FIFA resale site first";
      document.getElementById("last-scan").style.color="#ef4444";
    } else {
      document.getElementById("last-scan").textContent="Ready";
      document.getElementById("last-scan").style.color="";
    }
  });
  chrome.runtime.onMessage.addListener(m=>{
    if(m.type==="DATA_UPDATED"){chrome.storage.local.get("seats",d=>{allSeats=d.seats||{};refreshAll();if(currentScanPerfId)checkFVAlertLive(currentScanPerfId);});}
    if(m.type==="SCAN_PROGRESS"){const dn=m.done||m.completed||0;const t=m.total||16;if(selGame?.p===m.performanceId)showPct(Math.round((dn/t)*100));if(m.status==="done"||m.status==="captcha"){unhighlight(m.performanceId);currentScanPerfId=null;if(selGame?.p===m.performanceId){showPct(100);setTimeout(hidePct,2000);}chrome.storage.local.get("seats",d=>{allSeats=d.seats||{};refreshAll();});onScanDone();}}
    if(m.type==="SCAN_DONE"){unhighlight(m.performanceId);currentScanPerfId=null;if(selGame?.p===m.performanceId){showPct(100);setTimeout(hidePct,2000);}chrome.storage.local.get("seats",d=>{allSeats=d.seats||{};refreshAll();});onScanDone();}
    if(m.type==="FV_ALERT"){showToast(m.message,m.perfId);playChime();alertRow(m.perfId);}
  });
}

function refreshAll(){for(const g of GAMES)updRow(g.p);if(selGame){renderCats();renderSeats();renderStatus();}}
function slp(ms){return new Promise(r=>setTimeout(r,ms));}

function bindEvents(){
  document.getElementById("btn-stop").addEventListener("click",stopEverything);
  document.getElementById("btn-rescan").addEventListener("click",()=>{if(selGame)doScan(selGame.p);});
  document.getElementById("btn-clear").addEventListener("click",()=>{if(!selGame)return;chrome.storage.local.get("seats",d=>{const s=d.seats||{};delete s[selGame.p];chrome.storage.local.set({seats:s},()=>{allSeats=s;refreshAll();hidePct();});});});
  document.getElementById("pg-prev").addEventListener("click",()=>{if(page>0){page--;renderSeats();}});
  document.getElementById("pg-next").addEventListener("click",()=>{page++;renderSeats();});
  document.getElementById("search").addEventListener("input",e=>{const q=e.target.value.toLowerCase();document.querySelectorAll("#tbody tr").forEach(r=>{r.style.display=(!q||r.dataset.s.includes(q))?"":"none";});});
}

function stopEverything(){globalStop=true;scanning=false;if(currentScanPerfId)unhighlight(currentScanPerfId);currentScanPerfId=null;onScanDone();document.getElementById("btn-stop").classList.add("hidden");document.getElementById("prog-text").textContent="";document.getElementById("last-scan").textContent="Stopped";hidePct();setTimeout(()=>{globalStop=false;},100);}

// ── Table ────────────────────────────────────────────────────────────────────
function renderTable(){
  const tb=document.getElementById("tbody");tb.innerHTML="";
  for(const g of GAMES){
    const tr=document.createElement("tr");tr.dataset.p=g.p;
    tr.dataset.s=[g.c,g.h,g.a,g.v,g.d,g.g].join(" ").toLowerCase();
    tr.innerHTML=`<td><span class="n-grp">${esc(g.g)}</span><span class="n-code">${esc(g.c)}</span></td><td class="t-name">${esc(g.h)}</td><td class="t-name">${esc(g.a)}</td><td class="t-date">${esc(g.d)}</td><td class="t-venue" title="${esc(g.v)}">${esc(g.v)}</td><td class="t-low" id="lo-${g.p}"><span class="no">—</span></td><td class="t-act"><button class="scan-btn" data-p="${g.p}">SCAN</button></td>`;
    tr.addEventListener("click",e=>{if(e.target.tagName==="BUTTON")return;selectGame(g);});
    tr.querySelector(".scan-btn").addEventListener("click",e=>{e.stopPropagation();doScan(g.p);});
    tb.appendChild(tr);
  }
}

function updRow(perfId){
  const lo=document.getElementById("lo-"+perfId);if(!lo)return;
  const seats=allSeats[perfId];
  if(seats&&Object.keys(seats).length>0){let b=null;for(const s of Object.values(seats)){if(s.price&&(!b||s.price<b))b=s.price;}lo.innerHTML=b?`<span class="price">$${Math.round(b/1000*FIFA_FEE).toLocaleString()}</span>`:'<span class="no">—</span>';}
  else lo.innerHTML='<span class="no">—</span>';
}

function selectGame(g){
  selGame=g;document.querySelectorAll("#tbody tr").forEach(r=>r.classList.remove("sel"));
  document.querySelector(`tr[data-p="${g.p}"]`)?.classList.add("sel");
  document.getElementById("empty-msg").classList.add("hidden");
  ["r-header","cat-tabs","seats-wrap","r-status","r-pag"].forEach(id=>document.getElementById(id).classList.remove("hidden"));
  document.getElementById("r-grp").textContent=g.g;document.getElementById("r-code").textContent=g.c;
  document.getElementById("r-teams").textContent=g.h+(g.a&&g.a!=="TBD"?" vs "+g.a:"");
  document.getElementById("r-meta").textContent=g.v+" · "+g.d;
  catFilter="all";page=0;renderCats();renderSeats();renderStatus();
}

// ── Scan ─────────────────────────────────────────────────────────────────────
function startCooldown() {
  scanCooldown = 20;
  const el = document.getElementById("cooldown-timer");
  el.classList.remove("hidden");
  el.textContent = `⏳ ${scanCooldown}s`;
  // Disable all scan buttons
  document.querySelectorAll(".scan-btn").forEach(b => b.disabled = true);
  document.getElementById("btn-rescan").disabled = true;
  if (cooldownTimer) clearInterval(cooldownTimer);
  cooldownTimer = setInterval(() => {
    scanCooldown--;
    if (scanCooldown <= 0) {
      clearInterval(cooldownTimer);
      cooldownTimer = null;
      scanCooldown = 0;
      el.classList.add("hidden");
      // Re-enable scan buttons
      document.querySelectorAll(".scan-btn").forEach(b => b.disabled = false);
      document.getElementById("btn-rescan").disabled = false;
    } else {
      el.textContent = `⏳ ${scanCooldown}s`;
    }
  }, 1000);
}

function doScan(perfId,autoSelect){
  // Enforce cooldown
  if (scanCooldown > 0) return;
  highlight(perfId);currentScanPerfId=perfId;alertedGames.delete(perfId);
  document.getElementById("btn-stop").classList.remove("hidden");
  if(autoSelect){const g=GAMES.find(x=>x.p===perfId);if(g)selectGame(g);}
  chrome.storage.local.get("seats",d=>{
    const s=d.seats||{};s[perfId]={};
    chrome.storage.local.set({seats:s},()=>{allSeats=s;refreshAll();
      chrome.tabs.query({url:"https://*.tickets.fifa.com/*"},tabs=>{
        if(tabs&&tabs.length>0){
          chrome.tabs.sendMessage(tabs[0].id,{type:"START_SCAN",productId:PRODUCT_ID,performanceId:perfId});
          startCooldown();
        }
        else{alert("Open the FIFA resale site in a tab first.");unhighlight(perfId);}
      });
    });
  });
}

function waitDone(){return new Promise(resolve=>{scanDoneResolve=resolve;setTimeout(()=>{if(scanDoneResolve===resolve){scanDoneResolve=null;resolve();}},90000);});}
function onScanDone(){if(scanDoneResolve){const r=scanDoneResolve;scanDoneResolve=null;r();}}

// ── Right panel ──────────────────────────────────────────────────────────────
function grouped(perfId){
  const seats=allSeats[perfId];if(!seats)return[];
  const g=GAMES.find(x=>x.p===perfId);const mn=g?parseInt(g.c.replace("M","")):0;
  const sl=Object.entries(seats).filter(([,s])=>s.price>0).map(([id,s])=>({...s,seatId:id}));
  sl.sort((a,b)=>{if(a.block!==b.block)return a.block.localeCompare(b.block,undefined,{numeric:true});if(a.row!==b.row)return a.row.localeCompare(b.row,undefined,{numeric:true});return a.price-b.price;});
  const gm=new Map();for(const s of sl){const k=s.block+"|"+s.row+"|"+s.price;if(!gm.has(k))gm.set(k,[]);gm.get(k).push(s);}
  const out=[];
  for(const[,gr]of gm){gr.sort((a,b)=>(a.seat||"").localeCompare(b.seat||"",undefined,{numeric:true}));let i=0;
    while(i<gr.length){const run=[gr[i]];let j=i+1;while(j<gr.length){const p=parseInt(gr[j-1].seat),c=parseInt(gr[j].seat);if(!isNaN(p)&&!isNaN(c)&&c===p+1){run.push(gr[j]);j++;}else break;}
    const f=run[0],sn=run.map(x=>x.seat);const cn=parseInt((f.category||"").replace(/[^0-9]/g,""))||0;const usd=Math.round(f.price/1000*FIFA_FEE);const fv=FV[mn]?.[cn]||null;
    out.push({block:f.block,row:f.row,seats:run.length===1?sn[0]:sn[0]+"-"+sn[sn.length-1],count:run.length,cat:f.category,cn,usd,fv,mn});i=j;}}
  out.sort((a,b)=>a.usd-b.usd);return out;
}

function renderCats(){const c=document.getElementById("cat-tabs");if(!selGame){c.innerHTML="";return;}const g=grouped(selGame.p),cc={};for(const x of g){const cat=normCat(x.cat);cc[cat]=(cc[cat]||0)+x.count;}let h=`<button class="cat-tab ${catFilter==="all"?"on":""}" data-c="all">All<span class="cnt">(${g.reduce((s,x)=>s+x.count,0)})</span></button>`;for(const cat of Object.keys(cc).sort())h+=`<button class="cat-tab ${catFilter===cat?"on":""}" data-c="${esc(cat)}">${esc(cat)}<span class="cnt">(${cc[cat]})</span></button>`;c.innerHTML=h;c.querySelectorAll(".cat-tab").forEach(b=>b.addEventListener("click",()=>{catFilter=b.dataset.c;page=0;c.querySelectorAll(".cat-tab").forEach(x=>x.classList.remove("on"));b.classList.add("on");renderSeats();renderStatus();}));}

function renderSeats(){
  const tb=document.getElementById("seats-tbody");if(!selGame){tb.innerHTML="";return;}
  let g=grouped(selGame.p);if(catFilter!=="all")g=g.filter(x=>normCat(x.cat)===catFilter);
  const tp=Math.max(1,Math.ceil(g.length/PPG));if(page>=tp)page=tp-1;
  const items=g.slice(page*PPG,(page+1)*PPG);tb.innerHTML="";
  for(const x of items){
    const isDeal=x.fv&&x.usd<=x.fv,isNear=x.fv&&!isDeal&&x.usd<=x.fv*1.2;
    let fvL="—";if(x.fv){if(isDeal)fvL=`✓$${x.fv}`;else if(isNear)fvL=`~$${x.fv}`;else fvL=`$${x.fv}`;}
    const tr=document.createElement("tr");
    tr.innerHTML=`<td><span class="s-cat c${x.cn}">Cat ${x.cn}</span></td><td class="s-blk">${esc(x.block)}</td><td class="s-row">${esc(x.row)}</td><td class="s-num">${esc(x.seats)}</td><td class="s-usd">$${x.usd.toLocaleString()}</td><td class="s-fv ${isDeal?"deal":isNear?"near":""}">${fvL}</td><td><button class="cart-btn">Go</button></td>`;
    tr.querySelector(".cart-btn").addEventListener("click",()=>{
      chrome.storage.local.set({findSeat:{block:x.block,row:x.row,seats:x.seats,cat:x.cn,usd:x.usd}},()=>{
        chrome.tabs.create({url:`${FIFA_ORIGIN}/secured/selection/event/seat?perfId=${selGame.p}&productId=${PRODUCT_ID}&lang=en`});
      });
    });
    tb.appendChild(tr);
  }
  document.getElementById("pg-info").textContent=(page+1)+"/"+tp;
  document.getElementById("pg-prev").disabled=page===0;document.getElementById("pg-next").disabled=page>=tp-1;
}

function renderStatus(){if(!selGame)return;let g=grouped(selGame.p);if(catFilter!=="all")g=g.filter(x=>normCat(x.cat)===catFilter);const ts=g.reduce((s,x)=>s+x.count,0),ch=g.length>0?g[0].usd:0;const deals=g.filter(x=>x.fv&&x.usd<=x.fv*1.2).reduce((s,x)=>s+x.count,0);let txt=ts+" seats"+(ch?" · cheapest ~$"+ch.toLocaleString():"");if(deals>0)txt+=` · ${deals} at/near FV`;document.getElementById("r-status-text").textContent=txt;}

// ── FV Alerts (live) ─────────────────────────────────────────────────────────
function checkFVAlertLive(perfId){if(alertedGames.has(perfId))return;const g=GAMES.find(x=>x.p===perfId);if(!g)return;const mn=parseInt(g.c.replace("M",""));const fvD=FV[mn];if(!fvD)return;const seats=allSeats[perfId];if(!seats)return;let best=null;for(const s of Object.values(seats)){if(!s.price)continue;const cn=parseInt((s.category||"").replace(/[^0-9]/g,""))||0;const fv=fvD[cn];if(!fv)continue;const usd=Math.round((s.price/1000)*FIFA_FEE);if(usd<=fv*1.2&&(!best||usd<best.usd))best={usd,fv,cn};}if(best){alertedGames.add(perfId);const pct=Math.round((best.usd/best.fv-1)*100);const label=best.usd<=best.fv?"AT/BELOW FV":`${pct}% over FV`;const msg=`${g.c} ${g.h} vs ${g.a} — Cat ${best.cn} $${best.usd} (${label})`;playChime();alertRow(perfId);showToast(msg,perfId);}}

// ── UI helpers ───────────────────────────────────────────────────────────────
function highlight(p){document.querySelectorAll("#tbody tr.scanning-row").forEach(r=>r.classList.remove("scanning-row"));const row=document.querySelector(`tr[data-p="${p}"]`);if(row){row.classList.add("scanning-row");row.scrollIntoView({block:"center",behavior:"smooth"});}}
function unhighlight(p){document.querySelector(`tr[data-p="${p}"]`)?.classList.remove("scanning-row");}
function alertRow(p){const r=document.querySelector(`tr[data-p="${p}"]`);if(r){r.classList.add("alert-row");setTimeout(()=>r.classList.remove("alert-row"),30000);}}
function showPct(p){const el=document.getElementById("r-scan-pct");if(el){el.classList.remove("hidden");document.getElementById("scan-pct-text").textContent=p+"%";}}
function hidePct(){document.getElementById("r-scan-pct")?.classList.add("hidden");}

function showToast(text,perfId){const c=document.getElementById("alert-area"),t=document.createElement("div");t.className="alert-toast";t.innerHTML=`<span class="a-icon">💰</span><span class="a-msg">${esc(text)}</span><span class="a-time">${new Date().toLocaleTimeString()}</span><button class="a-close">✕</button>`;t.addEventListener("click",e=>{if(e.target.classList.contains("a-close")){t.remove();return;}const g=GAMES.find(x=>x.p===perfId);if(g)selectGame(g);});t.querySelector(".a-close").addEventListener("click",e=>{e.stopPropagation();t.remove();});c.prepend(t);setTimeout(()=>t.remove(),60000);}

function playChime(){try{const ctx=new(window.AudioContext||window.webkitAudioContext)();[523.25,659.25,783.99].forEach((f,i)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.connect(g);g.connect(ctx.destination);o.frequency.value=f;o.type="sine";g.gain.setValueAtTime(0.18,ctx.currentTime+i*0.12);g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+i*0.12+0.4);o.start(ctx.currentTime+i*0.12);o.stop(ctx.currentTime+i*0.12+0.4);});}catch{}}

function normCat(c){if(!c)return"Unknown";const m=c.match(/(\d)/);return m?"Cat "+m[1]:c;}
function esc(s){if(!s)return"";return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}
