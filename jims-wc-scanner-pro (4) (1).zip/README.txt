===============================================
  Jims WC Scanner - Installation Guide
===============================================

WINDOWS:
1. Right-click the zip file and select Extract All
2. Open the extracted folder
3. Open Chrome and go to: chrome://extensions
4. Turn ON Developer mode (toggle in top-right corner)
5. Click Load unpacked
6. Select the folder that directly contains manifest.json
7. The extension icon appears in your Chrome toolbar
8. Click the icon, enter your license key, and you are ready

MAC:
1. Double-click the zip file to extract it
2. A folder will appear next to the zip
3. Open Chrome and go to: chrome://extensions
4. Turn ON Developer mode (toggle in top-right corner)
5. Click Load unpacked
6. Navigate to the extracted folder
7. IMPORTANT: Click the folder ONCE to highlight it
   then click the Select button at the bottom
   Do NOT double-click the folder
8. If you get a security error, open Terminal and run:
   xattr -cr ~/Downloads/jims-wc-scanner-pro
   Then try loading again
9. The extension icon appears in your Chrome toolbar
10. Click the icon, enter your license key, and you are ready

USING THE SCANNER:
1. Open the FIFA resale site in a tab:
   https://fwc26-resale-usd.tickets.fifa.com/
2. Log into your FIFA account
3. Navigate to any match seat map and let it load
4. Click the extension icon to open the scanner
5. Click SCAN next to any game
6. Wait 20-30 seconds for results
7. Click Go next to any seat to view it on FIFA

TROUBLESHOOTING:
- Could not load icon = You selected the wrong folder.
  Make sure manifest.json is directly inside the folder
  you select, not in a subfolder.

- Extension not scanning = Make sure you have a FIFA
  resale tab open. Browse to a seat map page first,
  wait for it to load, then try scanning.

- Scan returns 0 seats = Refresh the FIFA tab, browse
  to a seat map, wait 10 seconds, try again.

- Mac security error = Open Terminal and run:
  xattr -cr PATH_TO_FOLDER
  Replace PATH_TO_FOLDER with the actual folder path.

- License key not working = Make sure you enter it
  exactly as provided with dashes. You need an internet
  connection for validation.
