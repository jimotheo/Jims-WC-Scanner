// Runs in PAGE context — intercepts fetch/XHR responses
// and relays matching ones back to the content script via postMessage

(function () {
  if (window.__jimsWCScanner) return;
  window.__jimsWCScanner = true;
  console.log("[Jim's WC Scanner] Injected script loaded successfully");
  const MATCH_PATTERNS = ["/seatmap/", "/performance/"];

  function shouldCapture(url) {
    return MATCH_PATTERNS.some((p) => url.includes(p));
  }

  // Capture headers from real requests so the scan can reuse them
  let capturedHeaders = null;

  // Patch fetch
  const originalFetch = window.fetch;
  window.fetch = async function (...args) {
    const url = typeof args[0] === "string" ? args[0] : args[0]?.url || "";

    // Capture headers from any seatmap request the page makes
    if (shouldCapture(url)) {
      const init = args[1] || {};
      if (init.headers) {
        capturedHeaders = init.headers instanceof Headers
          ? Object.fromEntries(init.headers.entries())
          : { ...init.headers };
      }
    }

    const response = await originalFetch.apply(this, args);

    if (shouldCapture(url)) {
      try {
        const clone = response.clone();
        const body = await clone.json();
        window.postMessage(
          { type: "FIFA_TICKET_SCOUT", url, body },
          "*"
        );
      } catch {
        // not JSON or parse error
      }
    }

    return response;
  };

  // Patch XMLHttpRequest — also capture headers
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;
  const originalSetHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...rest) {
    this._ftsUrl = url;
    this._ftsHeaders = {};
    return originalOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (this._ftsHeaders) {
      this._ftsHeaders[name] = value;
    }
    return originalSetHeader.call(this, name, value);
  };

  XMLHttpRequest.prototype.send = function (...args) {
    if (this._ftsUrl && shouldCapture(this._ftsUrl)) {
      // Capture headers from real XHR requests
      if (this._ftsHeaders && Object.keys(this._ftsHeaders).length > 0) {
        capturedHeaders = { ...this._ftsHeaders };
      }

      this.addEventListener("load", function () {
        try {
          const body = JSON.parse(this.responseText);
          window.postMessage(
            { type: "FIFA_TICKET_SCOUT", url: this._ftsUrl, body },
            "*"
          );
        } catch {
          // not JSON
        }
      });
    }
    return originalSend.apply(this, args);
  };

  // Listen for scan commands from the content script
  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    if (event.data?.type !== "FIFA_TICKET_SCOUT_SCAN") return;

    const { productId, performanceId, scanSpeed } = event.data;
    if (!productId || !performanceId) return;
    console.log("[Jim's WC Scanner] Scan started for", performanceId, "speed:", scanSpeed || "balanced");

    const baseUrl = `/tnwr/v1/secure/seatmap/seats/free/ol`;

    // Build headers — use captured ones or construct a set that mimics FIFA's own requests
    const headers = capturedHeaders
      ? { ...capturedHeaders }
      : {
          "Accept": "application/json, text/plain, */*",
          "X-Secutix-Host": window.location.hostname,
          "X-Secutix-SecretKey": "DUMMY",
          "X-Requested-With": "XMLHttpRequest",
        };

    // Ensure required headers are present
    if (!headers["X-Secutix-Host"]) {
      headers["X-Secutix-Host"] = window.location.hostname;
    }
    if (!headers["X-Secutix-SecretKey"]) {
      headers["X-Secutix-SecretKey"] = "DUMMY";
    }

    // Also try to get CSRF token from the page if not in headers
    if (!headers["X-CSRF-Token"]) {
      const csrfMeta = document.querySelector('meta[name="csrf-token"]');
      if (csrfMeta) headers["X-CSRF-Token"] = csrfMeta.content;
    }

    console.log("[Jim's WC Scanner] Using headers:", Object.keys(headers).join(", "), capturedHeaders ? "(captured)" : "(fallback)");

    const tileSize = 10000;
    const mapMax = 40000;

    // 10k tiles on 5k-aligned grid covering 0-40k (mimics site's native pattern)
    const tiles = [];
    for (let x = 0; x < mapMax; x += tileSize) {
      for (let y = 0; y < mapMax; y += tileSize) {
        tiles.push({ x, y, w: tileSize, h: tileSize });
      }
    }
    // Shuffle tiles to avoid always hitting the same one first
    for (let i = tiles.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [tiles[i], tiles[j]] = [tiles[j], tiles[i]];
    }
    const totalTiles = tiles.length;

    const SPEED_PROFILES = {
      stealth:    { min: 1300, max: 2275 },
      cautious:   { min: 500,  max: 900 },
      balanced:   { min: 900,  max: 1500 },
      aggressive: { min: 0,    max: 0 },
    };
    const profile = SPEED_PROFILES[scanSpeed] || SPEED_PROFILES.balanced;
    const DELAY_MIN = profile.min;
    const DELAY_MAX = profile.max;
    const AVG_DELAY = (DELAY_MIN + DELAY_MAX) / 2;

    let completed = 0;
    let foundSeats = 0;
    let consecutiveBlocks = 0;
    let consecutiveEmpties = 0;
    let foundAnySeats = false;
    const MAX_CONSECUTIVE_BLOCKS = 3;
    const MAX_CONSECUTIVE_EMPTIES = Math.max(Math.floor(totalTiles / 4), 5);

    window.postMessage({
      type: "FIFA_TICKET_SCOUT_SCAN_PROGRESS",
      performanceId,
      completed: 0,
      total: totalTiles,
      status: "scanning",
      eta: Math.round((totalTiles * AVG_DELAY) / 1000),
    }, "*");

    let aborted = false;
    let abortReason = null;

    // Scan a list of tiles, return any that were blocked
    async function scanTiles(tilesToScan) {
      const blocked = [];
      for (const tile of tilesToScan) {
        if (aborted) break;
        if (consecutiveBlocks >= MAX_CONSECUTIVE_BLOCKS) {
          console.log("[Jim's WC Scanner] Rate limited — stopping after", MAX_CONSECUTIVE_BLOCKS, "consecutive blocks");
          window.postMessage({
            type: "FIFA_TICKET_SCOUT_SCAN_PROGRESS",
            performanceId,
            completed: totalTiles,
            total: totalTiles,
            status: "captcha",
          }, "*");
          abortReason = "captcha";
          aborted = true;
          break;
        }
        if (foundAnySeats && consecutiveEmpties >= MAX_CONSECUTIVE_EMPTIES) {
          console.log("[Jim's WC Scanner] Stopping early — no more seats in remaining tiles");
          aborted = true;
          break;
        }

        const bbox = tile.x + "," + tile.y + "," + tile.w + "," + tile.h;
        const url = baseUrl + "?productId=" + productId + "&performanceId=" + performanceId + "&isSeasonTicketMode=false&advantageId=&isModifyAllSeatsMode=false&ppid=&reservationIdx=&crossSellId=&baseOperationIdsString=&bbox=" + bbox + "&isExclusive=true";

        try {
          const resp = await originalFetch(url, {
            credentials: "include",
            headers,
          });
          if (resp.ok) {
            consecutiveBlocks = 0;
            const body = await resp.json();
            const count = body.features ? body.features.length : 0;
            if (count > 0) {
              foundSeats += count;
              foundAnySeats = true;
              consecutiveEmpties = 0;
              console.log("[Jim's WC Scanner] Tile found", count, "seats (total:", foundSeats + ")");
            } else {
              if (foundAnySeats) consecutiveEmpties++;
            }
            window.postMessage(
              { type: "FIFA_TICKET_SCOUT", url: window.location.origin + url, body },
              "*"
            );
          } else {
            const ct = resp.headers.get("content-type") || "";
            if ((resp.status === 403 || resp.status === 429) && !ct.includes("application/json")) {
              consecutiveBlocks++;
              blocked.push(tile);
              console.log("[Jim's WC Scanner] Tile blocked (", resp.status, ") —", consecutiveBlocks, "consecutive");
            } else {
              const errText = await resp.text().catch(() => "");
              console.log("[Jim's WC Scanner] Tile failed:", resp.status, errText.substring(0, 200));
            }
          }
        } catch (err) {
          console.log("[Jim's WC Scanner] Scan tile error:", err.message);
          blocked.push(tile);
        }

        completed++;
        const remaining = totalTiles - completed;
        const eta = Math.round((remaining * (AVG_DELAY + 500)) / 1000);
        window.postMessage({
          type: "FIFA_TICKET_SCOUT_SCAN_PROGRESS",
          performanceId,
          completed,
          total: totalTiles,
          status: "scanning",
          eta,
        }, "*");

        const jitter = DELAY_MIN + Math.random() * (DELAY_MAX - DELAY_MIN);
        await new Promise((r) => setTimeout(r, jitter));
      }
      return blocked;
    }

    // First pass
    const blockedTiles = await scanTiles(tiles);

    // Retry blocked tiles — up to 3 attempts with increasing delays
    let blocked = blockedTiles;
    const retryDelays = [3000, 5000, 8000];
    for (let attempt = 0; attempt < retryDelays.length && blocked.length > 0 && !aborted; attempt++) {
      console.log("[Jim's WC Scanner] Retry", attempt + 1, "—", blocked.length, "blocked tiles in", retryDelays[attempt] / 1000 + "s...");
      await new Promise((r) => setTimeout(r, retryDelays[attempt]));
      consecutiveBlocks = 0;
      completed = totalTiles - blocked.length;
      blocked = await scanTiles(blocked);
      if (blocked.length === 0) {
        console.log("[Jim's WC Scanner] All tiles recovered on retry", attempt + 1);
        break;
      }
    }
    if (blocked.length > 0) {
      console.log("[Jim's WC Scanner]", blocked.length, "tiles still blocked after all retries");
    }

    if (abortReason !== "captcha") {
      window.postMessage({
        type: "FIFA_TICKET_SCOUT_SCAN_PROGRESS",
        performanceId,
        completed: totalTiles,
        total: totalTiles,
        status: "done",
      }, "*");
    }
    console.log("[Jim's WC Scanner] Scan", aborted ? "aborted (" + (abortReason || "failures") + ")" : "complete", ":", foundSeats, "seats found");
  });
})();
