// Background — FV alerts + data sync

const PRODUCT_ID = "10229225515651";
const FIFA_FEE = 1.15;

// Supabase config — replace with real values
const SUPABASE_URL = "https://bpqysjydesqukjvzwvhy.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJwcXlzanlkZXNxdWtqdnp3dmh5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYyMDM2NTMsImV4cCI6MjA5MTc3OTY1M30.xAQGjpxmVe1CbgaWIH5yoMZb-Lm6BwGCuH8x590_bvA";

const FV={
1:{1:2985,2:2260,3:1410,4:370},2:{1:500,2:400,3:180,4:60},3:{1:2240,2:1645,3:980,4:355},
4:{1:2735,2:1940,3:1120,4:560},5:{1:500,2:400,3:180,4:70},6:{1:450,2:380,3:140,4:70},
7:{1:790,2:575,3:315,4:105},8:{1:450,2:380,3:140,4:105},9:{1:500,2:400,3:180,4:75},
10:{1:500,2:400,3:180,4:70},11:{1:600,2:430,3:220,4:75},12:{1:450,2:380,3:140,4:60},
13:{1:600,2:430,3:220,4:60},14:{1:500,2:400,3:180,4:60},15:{1:450,2:380,3:140,4:60},
16:{1:500,2:400,3:180,4:60},17:{1:675,2:520,3:255,4:60},18:{1:500,2:400,3:180,4:60},
19:{1:765,2:565,3:310,4:60},20:{1:450,2:380,3:140,4:60},21:{1:450,2:380,3:140,4:60},
22:{1:775,2:570,3:310,4:60},23:{1:700,2:500,3:265,4:60},24:{1:600,2:430,3:220,4:60},
25:{1:450,2:380,3:140,4:60},26:{1:500,2:400,3:180,4:60},27:{1:750,2:550,3:300,4:80},
28:{1:795,2:590,3:325,4:75},29:{1:760,2:560,3:305,4:60},30:{1:655,2:480,3:255,4:60},
31:{1:450,2:380,3:140,4:60},32:{1:775,2:570,3:310,4:90},33:{1:645,2:475,3:250,4:75},
34:{1:500,2:400,3:180,4:70},35:{1:600,2:430,3:220,4:70},36:{1:450,2:380,3:140,4:60},
37:{1:500,2:400,3:180,4:75},38:{1:600,2:430,3:220,4:70},39:{1:500,2:400,3:180,4:105},
40:{1:450,2:380,3:140,4:70},41:{1:620,2:465,3:220,4:60},42:{1:600,2:430,3:220,4:60},
43:{1:775,2:570,3:315,4:60},44:{1:450,2:380,3:140,4:60},45:{1:660,2:490,3:260,4:60},
46:{1:500,2:400,3:180,4:60},47:{1:700,2:500,3:265,4:60},48:{1:555,2:455,3:215,4:60},
49:{1:770,2:570,3:310,4:60},50:{1:500,2:400,3:180,4:60},51:{1:700,2:500,3:265,4:80},
52:{1:500,2:400,3:180,4:60},53:{1:785,2:585,3:320,4:90},54:{1:450,2:380,3:140,4:60},
55:{1:450,2:380,3:140,4:60},56:{1:790,2:575,3:315,4:60},57:{1:500,2:400,3:180,4:60},
58:{1:500,2:400,3:180,4:60},59:{1:990,2:840,3:390,4:140},60:{1:450,2:380,3:140,4:60},
61:{1:775,2:570,3:310,4:60},62:{1:450,2:380,3:140,4:60},63:{1:500,2:400,3:180,4:60},
64:{1:500,2:400,3:180,4:60},65:{1:450,2:380,3:140,4:60},66:{1:780,2:575,3:315,4:60},
67:{1:675,2:520,3:255,4:105},68:{1:500,2:400,3:180,4:75},69:{1:450,2:380,3:140,4:70},
70:{1:765,2:565,3:310,4:75},71:{1:890,2:665,3:375,4:75},72:{1:450,2:380,3:140,4:70},
73:{1:790,2:605,3:305,4:185},74:{1:620,2:515,3:265,4:125},75:{1:460,2:350,3:190,4:105},
76:{1:530,2:430,3:220,4:125},77:{1:750,2:610,3:280,4:185},78:{1:505,2:405,3:205,4:135},
79:{1:685,2:550,3:280,4:125},80:{1:530,2:430,3:190,4:125},81:{1:765,2:605,3:275,4:185},
82:{1:515,2:430,3:200,4:125},83:{1:695,2:545,3:285,4:135},84:{1:700,2:555,3:250,4:185},
85:{1:645,2:570,3:260,4:125},86:{1:770,2:635,3:315,4:135},87:{1:520,2:425,3:200,4:125},
88:{1:540,2:440,3:225,4:135},89:{1:905,2:685,3:365,4:185},90:{1:620,2:505,3:220,4:170},
91:{1:1055,2:865,3:415,4:260},92:{1:960,2:695,3:400,4:170},93:{1:640,2:515,3:240,4:185},
94:{1:695,2:565,3:270,4:170},95:{1:795,2:640,3:305,4:180},96:{1:845,2:705,3:370,4:170},
97:{1:1400,2:1005,3:750,4:275},98:{1:1910,2:1345,3:900,4:410},99:{1:1590,2:1135,3:850,4:295},
100:{1:1360,2:1035,3:605,4:275},101:{1:3710,2:2705,3:1095,4:455},102:{1:3220,2:2725,3:995,4:420},
103:{1:1125,2:865,3:455,4:165},104:{1:10990,2:7380,3:5785,4:2030},
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_SEATS") {
    chrome.storage.local.get("seats", d => sendResponse({ seats: d.seats || {} }));
    return true;
  }
  if (msg.type === "SCAN_DONE") {
    chrome.runtime.sendMessage({ type: "SCAN_DONE", performanceId: msg.performanceId }).catch(() => {});
  }
  if (msg.type === "SCAN_PROGRESS") {
    chrome.runtime.sendMessage({ type: "SCAN_PROGRESS", ...msg }).catch(() => {});
  }
  if (msg.type === "DATA_UPDATED") {
    chrome.runtime.sendMessage({ type: "DATA_UPDATED" }).catch(() => {});
  }
});

const PERF_TO_GAME = {
"10229225516056":"M1|Mexico|South Africa",
"10229226700886":"M2|South Korea|Czechia",
"10229226700887":"M3|Canada|Bosnia & Herz.",
"10229226700888":"M4|USA|Paraguay",
"10229226700889":"M5|Haiti|Scotland",
"10229226700890":"M6|Australia|Türkiye",
"10229226700891":"M7|Brazil|Morocco",
"10229226700892":"M8|Qatar|Switzerland",
"10229226700893":"M9|Ivory Coast|Ecuador",
"10229226700895":"M10|Germany|Curaçao",
"10229226700896":"M11|Netherlands|Japan",
"10229226700906":"M12|Sweden|Tunisia",
"10229226700899":"M13|Saudi Arabia|Uruguay",
"10229226700902":"M14|Spain|Cape Verde",
"10229226700901":"M15|Iran|New Zealand",
"10229226700903":"M16|Belgium|Egypt",
"10229226700904":"M17|France|Senegal",
"10229226700905":"M18|Iraq|Norway",
"10229226700907":"M19|Argentina|Algeria",
"10229226700908":"M20|Austria|Jordan",
"10229226700909":"M21|Ghana|Panama",
"10229226700910":"M22|England|Croatia",
"10229226700911":"M23|Portugal|DR Congo",
"10229226700912":"M24|Uzbekistan|Colombia",
"10229226700913":"M25|Czechia|South Africa",
"10229226700914":"M26|Switzerland|Bosnia & Herz.",
"10229226700915":"M27|Canada|Qatar",
"10229226700916":"M28|Mexico|South Korea",
"10229226700917":"M29|Brazil|Haiti",
"10229226700918":"M30|Scotland|Morocco",
"10229226700919":"M31|Türkiye|Paraguay",
"10229226700920":"M32|USA|Australia",
"10229226700921":"M33|Germany|Ivory Coast",
"10229226700922":"M34|Ecuador|Curaçao",
"10229226700923":"M35|Netherlands|Sweden",
"10229226700924":"M36|Tunisia|Japan",
"10229226700925":"M37|Uruguay|Cape Verde",
"10229226700926":"M38|Spain|Saudi Arabia",
"10229226700927":"M39|Belgium|Iran",
"10229226700928":"M40|New Zealand|Egypt",
"10229226700929":"M41|Norway|Senegal",
"10229226700930":"M42|France|Iraq",
"10229226700931":"M43|Argentina|Austria",
"10229226700932":"M44|Jordan|Algeria",
"10229226700933":"M45|England|Ghana",
"10229226700934":"M46|Panama|Croatia",
"10229226700935":"M47|Portugal|Uzbekistan",
"10229226700936":"M48|Colombia|DR Congo",
"10229226700937":"M49|Scotland|Brazil",
"10229226700938":"M50|Morocco|Haiti",
"10229226700941":"M51|Switzerland|Canada",
"10229226700942":"M52|Bosnia & Herz.|Qatar",
"10229226700940":"M53|Czechia|Mexico",
"10229226700939":"M54|South Africa|South Korea",
"10229226700943":"M55|Curaçao|Ivory Coast",
"10229226700944":"M56|Ecuador|Germany",
"10229226700945":"M57|Japan|Sweden",
"10229226700946":"M58|Tunisia|Netherlands",
"10229226700947":"M59|Türkiye|USA",
"10229226700948":"M60|Paraguay|Australia",
"10229226700949":"M61|Norway|France",
"10229226700950":"M62|Senegal|Iraq",
"10229226700951":"M63|Egypt|Iran",
"10229226700952":"M64|New Zealand|Belgium",
"10229226700953":"M65|Cape Verde|Saudi Arabia",
"10229226700954":"M66|Uruguay|Spain",
"10229226700955":"M67|Panama|England",
"10229226700956":"M68|Croatia|Ghana",
"10229226700959":"M69|Algeria|Austria",
"10229226700960":"M70|Jordan|Argentina",
"10229226700957":"M71|Colombia|Portugal",
"10229226700958":"M72|DR Congo|Uzbekistan",
"10229226725328":"M73|TBD|TBD",
"10229226725329":"M74|TBD|TBD",
"10229226725330":"M75|TBD|TBD",
"10229226725331":"M76|TBD|TBD",
"10229226725332":"M77|TBD|TBD",
"10229226725333":"M78|TBD|TBD",
"10229226725334":"M79|TBD|TBD",
"10229226725335":"M80|TBD|TBD",
"10229226725336":"M81|TBD|TBD",
"10229226725337":"M82|TBD|TBD",
"10229226725338":"M83|TBD|TBD",
"10229226725339":"M84|TBD|TBD",
"10229226725340":"M85|TBD|TBD",
"10229226725341":"M86|TBD|TBD",
"10229226725342":"M87|TBD|TBD",
"10229226725343":"M88|TBD|TBD",
"10229226725345":"M89|TBD|TBD",
"10229226725346":"M90|TBD|TBD",
"10229226725347":"M91|TBD|TBD",
"10229226725348":"M92|TBD|TBD",
"10229226725349":"M93|TBD|TBD",
"10229226725350":"M94|TBD|TBD",
"10229226725351":"M95|TBD|TBD",
"10229226725352":"M96|TBD|TBD",
"10229226725353":"M97|TBD|TBD",
"10229226725354":"M98|TBD|TBD",
"10229226725355":"M99|TBD|TBD",
"10229226725356":"M100|TBD|TBD",
"10229226725357":"M101|TBD|TBD",
"10229226725358":"M102|TBD|TBD",
"10229226725361":"M103|TBD|TBD",
"10229226725360":"M104|TBD|TBD"
};

async function syncToSupabase(perfId) {
  if (!SUPABASE_URL || SUPABASE_URL === "YOUR_SUPABASE_URL") return;
  try {
    const data = await new Promise(r => chrome.storage.local.get(["seats", "licenseKey"], d => r(d)));
    const seats = data.seats?.[perfId];
    if (!seats || Object.keys(seats).length === 0) return;
    const seatList = Object.values(seats).map(s => ({
      block: s.block, row: s.row, seat: s.seat, category: s.category,
      price: s.price, usd: Math.round((s.price / 1000) * FIFA_FEE),
    }));
    const gameInfo = (PERF_TO_GAME[perfId] || "").split("|");
    const payload = {
      performance_id: perfId,
      license_hash: data.licenseKey ? await sha256(data.licenseKey) : "unknown",
      match_code: gameInfo[0] || "",
      home: gameInfo[1] || "",
      away: gameInfo[2] || "",
      seat_count: seatList.length,
      seats: seatList,
    };
    fetch(`${SUPABASE_URL}/rest/v1/scan_data`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "apikey": SUPABASE_KEY, "Authorization": "Bearer " + SUPABASE_KEY, "Prefer": "return=minimal" },
      body: JSON.stringify(payload),
    }).catch(() => {});
  } catch {}
}

async function sha256(str) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}
